
/**
 * Subclase de articulo para los bolsos
 * @author gianf
 */
public class Bolsos extends Articulo {

	private String tipoBolso;

	/**
	 * 
	 * @param tipo
	 */
	public Bolsos(String tipo) {
		// TODO - implement Bolsos.Bolsos
		throw new UnsupportedOperationException();
	}

    /**
     *
     * @return **
     */
    public String getTipoBolso() {
		return this.tipoBolso;
	}

	/**
	 * 
	 * @param tipoBolso
	 */
	public void setTipoBolso(String tipoBolso) {
		this.tipoBolso = tipoBolso;
	}

}