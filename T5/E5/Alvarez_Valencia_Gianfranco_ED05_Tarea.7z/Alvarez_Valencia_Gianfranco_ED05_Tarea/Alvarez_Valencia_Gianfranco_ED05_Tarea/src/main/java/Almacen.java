
/**
 *
 * @author gianf
 */
public class Almacen {

	private Paquete paqueteEnAlmacen;

    /**
     *
     */
    public Almacen() {
		// TODO - implement Almacen.Almacen
		throw new UnsupportedOperationException();
	}

    /**
     *
     * @return **
     */
    public Paquete getPaqueteEnAlmacen() {
		return this.paqueteEnAlmacen;
	}

	/**
	 * 
	 * @param paqueteEnAlmacen
	 */
	public void setPaqueteEnAlmacen(Paquete paqueteEnAlmacen) {
		this.paqueteEnAlmacen = paqueteEnAlmacen;
	}

}