
/**
 * subclase que representa a una empresa Proveedora
 * @author gianf
 */
public class Proveedor extends Empresa {

	private Firma firma;

	/**
	 * 
	 * @param firma
	 */
	public Proveedor(Firma firma) {
		// TODO - implement Proveedor.Proveedor
		throw new UnsupportedOperationException();
	}

    /**
     *
     * @return **
     */
    public Firma getFirma() {
		return this.firma;
	}

	/**
	 * 
	 * @param firma
	 */
	public void setFirma(Firma firma) {
		this.firma = firma;
	}

}