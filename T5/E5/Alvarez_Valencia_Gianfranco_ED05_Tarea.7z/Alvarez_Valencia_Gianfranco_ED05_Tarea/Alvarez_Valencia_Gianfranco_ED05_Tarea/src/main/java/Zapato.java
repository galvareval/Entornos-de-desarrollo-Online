
/**
 *
 * @author gianf
 */
public class Zapato extends Articulo {

	private int numero;
	private String tipoZapato;

	/**
	 * 
	 * @param numero
	 * @param tipoZapato
	 */
	public Zapato(int numero, String tipoZapato) {
		// TODO - implement Zapato.Zapato
		throw new UnsupportedOperationException();
	}

    /**
     *
     * @return **
     */
    public int getNumero() {
		return this.numero;
	}

	/**
	 * 
	 * @param numero *
	 */
	public void setNumero(int numero) {
		this.numero = numero;
	}

    /**
     *
     * @return **
     */
    public String getTipoZapato() {
		return this.tipoZapato;
	}

	/**
	 * 
	 * @param tipoZapato
	 */
	public void setTipoZapato(String tipoZapato) {
		this.tipoZapato = tipoZapato;
	}

}