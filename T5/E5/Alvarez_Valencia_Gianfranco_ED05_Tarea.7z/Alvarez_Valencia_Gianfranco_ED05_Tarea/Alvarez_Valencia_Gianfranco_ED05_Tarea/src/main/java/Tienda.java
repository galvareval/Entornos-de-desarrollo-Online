
/**
 * Clase principal del progama que representa la tienda
 * @author gianf
 */
public class Tienda {

	private Articulo articulos;
	private Socios socio;

	/**
	 * 
	 * @param articulo
	 */
	public Tienda(Articulo articulo) {
		// TODO - implement Tienda.Tienda
		throw new UnsupportedOperationException();
	}

    /**
     *
     */
    public Tienda() {
		// TODO - implement Tienda.Tienda
		throw new UnsupportedOperationException();
	}

    /**
     *
     * @return **
     */
    public Articulo getArticulos() {
		return this.articulos;
	}

	/**
	 * 
	 * @param articulos
	 */
	public void setArticulos(Articulo articulos) {
		this.articulos = articulos;
	}

}