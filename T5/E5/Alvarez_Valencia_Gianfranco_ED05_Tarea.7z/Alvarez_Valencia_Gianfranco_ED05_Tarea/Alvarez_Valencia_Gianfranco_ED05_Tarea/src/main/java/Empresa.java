
/**
 * Clase que representa las empresas
 * @author gianf
 */
public class Empresa {

	private String nombre;
	private String cif;
	private String domicilioFiscal;

    /**
     *
     * @param nombre
     * @param cif
     * @param domicilioFiscal
     */
    public Empresa(String nombre, String cif, String domicilioFiscal) {
		// TODO - implement Empresa.Empresa
		throw new UnsupportedOperationException();
	}

    /**
     *
     * @return *
     */
    public String getNombre() {
		return this.nombre;
	}

	/**
	 * 
	 * @param nombre
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

    /**
     *
     * @return **
     */
    public String getCif() {
		return this.cif;
	}

	/**
	 * 
	 * @param cif
	 */
	public void setCif(String cif) {
		this.cif = cif;
	}

    /**
     *
     * @return **
     */
    public String getDomicilioFiscal() {
		return this.domicilioFiscal;
	}

	/**
	 * 
	 * @param domicilioFiscal
	 */
	public void setDomicilioFiscal(String domicilioFiscal) {
		this.domicilioFiscal = domicilioFiscal;
	}


}