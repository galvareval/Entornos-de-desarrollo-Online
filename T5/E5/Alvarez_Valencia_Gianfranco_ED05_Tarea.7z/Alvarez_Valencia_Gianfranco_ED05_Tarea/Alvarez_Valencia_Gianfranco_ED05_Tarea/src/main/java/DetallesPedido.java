
/**
 * Clase para los detalles de los pedidos
 * @author gianf
 */
public class DetallesPedido {

	private Articulo articulo;
	private int cantidad;

	/**
	 * 
	 * @param articulo
	 * @param cantidad
	 */
	public DetallesPedido(Articulo articulo, int cantidad) {
		// TODO - implement DetallesPedido.DetallesPedido
		throw new UnsupportedOperationException();
	}

    /**
     *
     * @return *
     */
    public Articulo getArticulo() {
		return this.articulo;
	}

	/**
	 * 
	 * @param articulo
	 */
	public void setArticulo(Articulo articulo) {
		this.articulo = articulo;
	}

    /**
     *
     * @return *
     */
    public int getCantidad() {
		return this.cantidad;
	}

	/**
	 * 
	 * @param cantidad
	 */
	public void setCantidad(int cantidad) {
		this.cantidad = cantidad;
	}

}