
/**
 * Sublclase que representa a una empresa firma
 * @author gianf
 */
public class Firma extends Empresa {

	private Articulo articuloDeFirma;

	/**
	 * 
	 * @param art
	 */
	public Firma(Articulo art) {
		// TODO - implement Firma.Firma
		throw new UnsupportedOperationException();
	}

    /**
     *
     * @return **
     */
    public Articulo getArticuloDeFirma() {
		return this.articuloDeFirma;
	}

	/**
	 * 
	 * @param articuloDeFirma
	 */
	public void setArticuloDeFirma(Articulo articuloDeFirma) {
		this.articuloDeFirma = articuloDeFirma;
	}

}