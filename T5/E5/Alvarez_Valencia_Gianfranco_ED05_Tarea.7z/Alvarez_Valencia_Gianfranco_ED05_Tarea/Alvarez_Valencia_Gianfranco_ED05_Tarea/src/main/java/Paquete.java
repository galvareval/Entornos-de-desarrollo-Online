
/**
 * Clase que representa un paquete
 * @author gianf
 */
public class Paquete {

	private Pedidos pedidos;
	private boolean enAlmacen;
	private String destino;

	/**
	 * 
	 * @param pedidos
	 * @param enAlmacen
	 * @param destino
	 */
	public Paquete(Pedidos pedidos, boolean enAlmacen, String destino) {
		// TODO - implement Paquete.Paquete
		throw new UnsupportedOperationException();
	}

    /**
     *
     * @return **
     */
    public boolean getEnAlmacen() {
		return this.enAlmacen;
	}

	/**
	 * 
	 * @param enAlmacen
	 */
	public void setEnAlmacen(boolean enAlmacen) {
		this.enAlmacen = enAlmacen;
	}

    /**
     *
     * @return **
     */
    public Pedidos getPedidos() {
		return this.pedidos;
	}

	/**
	 * 
	 * @param pedidos
	 */
	public void setPedidos(Pedidos pedidos) {
		this.pedidos = pedidos;
	}

    /**
     *
     * @return **
     */
    public String getDestino() {
		return this.destino;
	}

	/**
	 * 
	 * @param destino
	 */
	public void setDestino(String destino) {
		this.destino = destino;
	}

}