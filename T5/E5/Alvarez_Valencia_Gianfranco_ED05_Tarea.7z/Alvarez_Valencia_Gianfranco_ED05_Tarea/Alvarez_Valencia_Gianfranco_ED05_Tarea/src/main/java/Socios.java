public class Socios {

	private String nombreCompleto;
	private String correoElectronico;
	private String direccion;
        
        /**
	 * 
	 * @param nombreCompleto
	 * @param correoElectronico
	 * @param direccion
	 */
	public Socios(String nombreCompleto, String correoElectronico, String direccion) {
		// TODO - implement Socios.Socios
		throw new UnsupportedOperationException();
	}
        
	public String getNombreCompleto() {
		return this.nombreCompleto;
	}

	/**
	 * 
	 * @param nombreCompleto
	 */
	public void setNombreCompleto(String nombreCompleto) {
		this.nombreCompleto = nombreCompleto;
	}

	public String getCorreoElectronico() {
		return this.correoElectronico;
	}

	/**
	 * 
	 * @param correoElectronico
	 */
	public void setCorreoElectronico(String correoElectronico) {
		this.correoElectronico = correoElectronico;
	}

	public String getDireccion() {
		return this.direccion;
	}

	/**
	 * 
	 * @param direccion
	 */
	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	

}