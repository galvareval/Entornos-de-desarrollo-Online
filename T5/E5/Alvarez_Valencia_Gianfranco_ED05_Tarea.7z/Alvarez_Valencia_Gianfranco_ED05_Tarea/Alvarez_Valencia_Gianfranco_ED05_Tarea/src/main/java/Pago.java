
/**
 *
 * @author gianf
 */
public class Pago {

	private String tarjetaBancaria;

	/**
	 * 
	 * @param tarjetaBancaria
	 */
	public Pago(String tarjetaBancaria) {
		// TODO - implement Pago.Pago
		throw new UnsupportedOperationException();
	}

    /**
     *
     * @return **
     */
    public String getTarjetaBancaria() {
		return this.tarjetaBancaria;
	}

	/**
	 * 
	 * @param tarjetaBancaria
	 */
	public void setTarjetaBancaria(String tarjetaBancaria) {
		this.tarjetaBancaria = tarjetaBancaria;
	}

}