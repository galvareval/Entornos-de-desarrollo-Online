
/**
 *
 * @author gianf
 */
public enum Campana {

    /**
     *
     */
    verano,

    /**
     *
     */
    otono,

    /**
     *
     */
    invierno,

    /**
     *
     */
    primavera
}