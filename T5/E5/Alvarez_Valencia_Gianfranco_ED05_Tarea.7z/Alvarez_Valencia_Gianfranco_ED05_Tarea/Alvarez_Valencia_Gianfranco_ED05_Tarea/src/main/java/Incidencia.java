
/**
 *
 * @author gianf
 */
public class Incidencia {

	private String fechaIncidencia;
	private String descripcion;

	/**
	 * 
	 * @param fechaIncidencia
	 * @param descripcion
	 */
	public Incidencia(String fechaIncidencia, String descripcion) {
		// TODO - implement Incidencia.Incidencia
		throw new UnsupportedOperationException();
	}

    /**
     *
     * @return **
     */
    public String getFechaIncidencia() {
		return this.fechaIncidencia;
	}

	/**
	 * 
	 * @param fechaIncidencia
	 */
	public void setFechaIncidencia(String fechaIncidencia) {
		this.fechaIncidencia = fechaIncidencia;
	}

    /**
     *
     * @return **
     */
    public String getDescripcion() {
		return this.descripcion;
	}

	/**
	 * 
	 * @param descripcion
	 */
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

}