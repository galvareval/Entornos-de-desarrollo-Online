
/**
 *
 * @author gianf
 */
public class Pedidos {

	private String fechaPedido;
	private float total;
	private DetallesPedido detalles;
	private Socios socio;
	private Pago pago;

    /**
     *
     * @param fechaPedido
     * @param total
     * @param detalles
     * @param socio
     * @param pago
     */
    public Pedidos(String fechaPedido, float total, DetallesPedido detalles, Socios socio, Pago pago) {
		// TODO - implement Pedidos.Pedidos
		throw new UnsupportedOperationException();
	}

    /**
     *
     * @return **
     */
    public String getFechaPedido() {
		return this.fechaPedido;
	}

	/**
	 * 
	 * @param fechaPedido
	 */
	public void setFechaPedido(String fechaPedido) {
		this.fechaPedido = fechaPedido;
	}

    /**
     *
     * @return **
     */
    public int getTotal() {
		// TODO - implement Pedidos.getTotal
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param total
	 */
	public void setTotal(int total) {
		// TODO - implement Pedidos.setTotal
		throw new UnsupportedOperationException();
	}

    /**
     *
     * @return **
     */
    public DetallesPedido getDetalles() {
		return this.detalles;
	}

	/**
	 * 
	 * @param detalles
	 */
	public void setDetalles(DetallesPedido detalles) {
		this.detalles = detalles;
	}

    /**
     *
     * @return **
     */
    public Socios getSocio() {
		return this.socio;
	}

	/**
	 * 
	 * @param socio
	 */
	public void setSocio(Socios socio) {
		this.socio = socio;
	}

    /**
     *
     * @return **
     */
    public Pago getPago() {
		return this.pago;
	}

	/**
	 * 
	 * @param pago
	 */
	public void setPago(Pago pago) {
		this.pago = pago;
	}

}