
/**
 *Clase que maneja los articos de la tienda
 * @author gianf
 */
public class Articulo {

	private String nombre;
	private String descripcion;
	private String material;
	private String color;
	private float precio;
	private int stock;
	private Campana campanaActual;

    /**
     *
     * @param nombre
     * @param descripcion
     * @param material
     * @param color
     * @param precio
     * @param stock
     * @param campanaActual
     */
    public Articulo(String nombre, String descripcion, String material, String color, float precio, int stock, Campana campanaActual) {
		
		
	}

    /**
     *
     */
    public Articulo() {
		// TODO - implement Articulo.Articulo
		throw new UnsupportedOperationException();
	}

}