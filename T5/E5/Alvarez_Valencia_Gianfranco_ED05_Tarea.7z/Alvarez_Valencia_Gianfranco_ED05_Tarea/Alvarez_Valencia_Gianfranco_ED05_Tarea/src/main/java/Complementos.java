
/**
 * Clase que representa los complementos
 * @author gianf
 */
public class Complementos extends Articulo {

	private int talla;

	/**
	 * 
	 * @param talla
	 */
	public Complementos(int talla) {
		// TODO - implement Complementos.Complementos
		throw new UnsupportedOperationException();
	}

    /**
     *
     * @return **
     */
    public int getTalla() {
		return this.talla;
	}

	/**
	 * 
	 * @param talla
	 */
	public void setTalla(int talla) {
		this.talla = talla;
	}

}