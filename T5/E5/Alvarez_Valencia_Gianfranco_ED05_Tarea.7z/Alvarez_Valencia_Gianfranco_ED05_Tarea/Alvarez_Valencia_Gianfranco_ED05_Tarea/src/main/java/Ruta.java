
/**
 *
 * @author gianf
 */
public class Ruta {

	private String areaInfluencia;
	private String diasDeReparto;
	private String fechaReparto;

	/**
	 * 
	 * @param areaInfluencia
	 * @param diasDeReparto
	 * @param fechaReparto
	 */
	public Ruta(String areaInfluencia, String diasDeReparto, String fechaReparto) {
		// TODO - implement Ruta.Ruta
		throw new UnsupportedOperationException();
	}

    /**
     *
     * @return **
     */
    public String getAreaInfluencia() {
		return this.areaInfluencia;
	}

	/**
	 * 
	 * @param areaInfluencia
	 */
	public void setAreaInfluencia(String areaInfluencia) {
		this.areaInfluencia = areaInfluencia;
	}

    /**
     *
     * @return **
     */
    public String getDiasDeReparto() {
		return this.diasDeReparto;
	}

	/**
	 * 
	 * @param diasDeReparto
	 */
	public void setDiasDeReparto(String diasDeReparto) {
		this.diasDeReparto = diasDeReparto;
	}

    /**
     *
     * @return **
     */
    public String getFechaReparto() {
		return this.fechaReparto;
	}

	/**
	 * 
	 * @param fechaReparto
	 */
	public void setFechaReparto(String fechaReparto) {
		this.fechaReparto = fechaReparto;
	}

}