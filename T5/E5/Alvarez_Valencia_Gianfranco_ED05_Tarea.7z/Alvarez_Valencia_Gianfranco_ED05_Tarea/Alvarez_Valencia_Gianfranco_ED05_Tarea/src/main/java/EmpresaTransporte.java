
/**
 * Clase para la emprea de transportes
 * @author gianf
 */
public class EmpresaTransporte extends Empresa {

	private Ruta ruta;
	private Paquete paquete;
	private String fechaReparto;
	private Incidencia incidencia;

	/**
	 * 
	 * @param ruta
	 * @param paquete
	 * @param fechaReparto
	 */
	public EmpresaTransporte(Ruta ruta, Paquete paquete, String fechaReparto) {
		// TODO - implement EmpresaTransporte.EmpresaTransporte
		throw new UnsupportedOperationException();
	}

    /**
     *
     * @return **
     */
    public Ruta getRuta() {
		return this.ruta;
	}

	/**
	 * 
	 * @param ruta
	 */
	public void setRuta(Ruta ruta) {
		this.ruta = ruta;
	}

    /**
     *
     * @return **
     */
    public Paquete getPaquete() {
		return this.paquete;
	}

	/**
	 * 
	 * @param paquete
	 */
	public void setPaquete(Paquete paquete) {
		this.paquete = paquete;
	}

    /**
     *
     * @return **
     */
    public String getFechaReparto() {
		return this.fechaReparto;
	}

	/**
	 * 
	 * @param fechaReparto
	 */
	public void setFechaReparto(String fechaReparto) {
		this.fechaReparto = fechaReparto;
	}

    /**
     *
     * @return **
     */
    public Incidencia getIncidencia() {
		return this.incidencia;
	}

	/**
	 * 
	 * @param incidencia
	 */
	public void setIncidencia(Incidencia incidencia) {
		this.incidencia = incidencia;
	}

}